﻿namespace CounterStrikeSharp.API.Core.Plugin;

public enum PluginState
{
    Unregistered,
    Loading,
    Loaded, 
    Unloaded,
}