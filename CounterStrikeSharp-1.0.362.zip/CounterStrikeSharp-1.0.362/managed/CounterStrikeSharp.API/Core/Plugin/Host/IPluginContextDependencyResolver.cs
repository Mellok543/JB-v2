﻿namespace CounterStrikeSharp.API.Core.Plugin.Host;

public interface IPluginContextDependencyResolver
{
    public string? ResolvePath();
}
