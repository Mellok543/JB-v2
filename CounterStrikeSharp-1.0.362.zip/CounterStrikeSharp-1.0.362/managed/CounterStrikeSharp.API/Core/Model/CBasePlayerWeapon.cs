﻿namespace CounterStrikeSharp.API.Core;

public partial class CBasePlayerWeapon
{
    public CBasePlayerWeaponVData? VData => GetVData<CBasePlayerWeaponVData>();
}