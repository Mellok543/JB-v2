﻿namespace CounterStrikeSharp.API.Core;

public interface IStartupService
{
    public void Load();
}