namespace CounterStrikeSharp.API.Tests.Fixtures;

[CollectionDefinition("Logging collection")]
public class LoggingCollection : ICollectionFixture<CoreLoggingFixture>
{
}