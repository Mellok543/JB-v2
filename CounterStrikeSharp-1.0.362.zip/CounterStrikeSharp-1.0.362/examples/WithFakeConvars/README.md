﻿# With Fake Convars
This is an example that shows how to register "fake" convars, which are actually console commands that track their internal state.