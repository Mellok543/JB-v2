﻿# With Dependency Injection
This example shows how can you implement the `IPluginServiceCollection` interface to register your services in a provided DI container.