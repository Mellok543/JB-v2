﻿# With Game Event Handlers
This is example shows how you can subscribe to legacy Source 1 game events.