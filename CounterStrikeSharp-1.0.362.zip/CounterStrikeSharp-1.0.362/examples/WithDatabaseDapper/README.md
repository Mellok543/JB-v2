﻿# With Database (Dapper)
Simple SQLite database example using Dapper library to track kills.