﻿namespace MySharedTypes.Contracts;

public interface IBalanceService
{
    public void ClearAllBalances();
}