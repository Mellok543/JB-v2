﻿# With Commands
This is an example that shows how to register chat & console commands.

All commands that are prefixed with "css_" will automatically be registered as a chat command without the prefix. i.e. `css_ping` can be called with `!ping` or `/ping`.