﻿# With Shared Types (Capabilities)

An example plugin that exposes a balance contract library, to use as a shared library between multiple plugins.

This allows one plugin to expose a capability for a player or plugin, and other plugins to use the exposed API.
