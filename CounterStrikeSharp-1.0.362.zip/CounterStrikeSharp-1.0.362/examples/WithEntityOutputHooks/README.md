﻿# With Entity Output Hooks
This example shows how to implement hooks for entity output, such as StartTouch, OnPickup etc.