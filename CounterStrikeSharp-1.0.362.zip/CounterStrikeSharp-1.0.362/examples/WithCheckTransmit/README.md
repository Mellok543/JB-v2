# With CheckTransmit
This example shows how to work with the `CheckTransmit` listener.
