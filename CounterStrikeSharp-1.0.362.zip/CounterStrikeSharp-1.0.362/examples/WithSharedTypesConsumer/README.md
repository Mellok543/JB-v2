﻿# With Shared Types (Consumer Plugin)
Uses the decimal balance shared library.