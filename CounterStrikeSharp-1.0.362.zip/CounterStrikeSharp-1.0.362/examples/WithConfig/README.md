﻿# With Config
This example shows how you can implement the `IPluginConfig` interface to allow for semi-automatic config parsing & loading.