Place your plugin configurations here.

TestPlugin/TestPlugin.json
AnotherPlugin/AnotherPlugin.json