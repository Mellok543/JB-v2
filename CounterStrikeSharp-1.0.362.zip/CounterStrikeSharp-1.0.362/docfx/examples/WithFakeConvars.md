[!INCLUDE [WithFakeConvars](../../examples/WithFakeConvars/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithFakeConvars" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithFakeConvars/WithFakeConvarsPlugin.cs)]