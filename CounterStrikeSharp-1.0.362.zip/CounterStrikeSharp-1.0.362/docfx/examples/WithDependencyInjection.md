[!INCLUDE [WithDependencyInjection](../../examples/WithDependencyInjection/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithDependencyInjection" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithDependencyInjection/WithDependencyInjectionPlugin.cs)]