[!INCLUDE [WithVirtualFunctions](../../examples/WithVirtualFunctions/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithVirtualFunctions" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithVirtualFunctions/WithVirtualFunctionsPlugin.cs)]