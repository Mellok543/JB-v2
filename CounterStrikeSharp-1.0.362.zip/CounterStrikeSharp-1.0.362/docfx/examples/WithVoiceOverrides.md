[!INCLUDE [WithVoiceOverrides](../../examples/WithVoiceOverrides/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithVoiceOverrides" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithVoiceOverrides/WithVoiceOverridesPlugin.cs)]