[!INCLUDE [Database](../../examples/WithDatabaseDapper/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithDatabaseDapper" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithDatabaseDapper/WithDatabaseDapperPlugin.cs)]