[!INCLUDE [WithUserMessages](../../examples/WithUserMessages/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithUserMessages" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithUserMessages/WithUserMessagesPlugin.cs)]