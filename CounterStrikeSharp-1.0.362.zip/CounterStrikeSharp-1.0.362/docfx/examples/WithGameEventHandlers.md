[!INCLUDE [WithGameEventHandlers](../../examples/WithGameEventHandlers/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithGameEventHandlers" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithGameEventHandlers/WithGameEventHandlersPlugin.cs)]