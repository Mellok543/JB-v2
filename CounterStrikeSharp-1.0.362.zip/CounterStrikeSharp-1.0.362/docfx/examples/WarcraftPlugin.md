# Warcraft Plugin

This Warcraft plugin is migrated from the previous VSP.NET project to give you an idea of the kind of power this scripting runtime is capable of.

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WarcraftPlugin" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

## Demonstrated
- Hook events
- Create commands
- Use third party libraries
  - SQLite
- Entity manipulation

