[!INCLUDE [WithCommands](../../examples/WithCommands/README.md)]

<a href="https://github.com/roflmuffin/CounterStrikeSharp/tree/main/examples/WithCommands" class="btn btn-secondary">View project on Github <i class="bi bi-github"></i></a>

[!code-csharp[](../../examples/WithCommands/WithCommandsPlugin.cs)]