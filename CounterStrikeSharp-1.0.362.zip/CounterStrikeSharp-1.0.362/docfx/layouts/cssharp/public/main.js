export default {
  iconLinks: [
    {
      icon: "github",
      href: "https://github.com/roflmuffin/CounterStrikeSharp",
      title: "GitHub",
    },
    {
      icon: "discord",
      href: "https://discord.gg/eAZU3guKWU",
      title: "Discord",
    },
  ],
};
